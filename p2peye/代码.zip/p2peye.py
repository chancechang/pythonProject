import json
from bs4 import BeautifulSoup
import time
from threading import Thread
from util import *


def get_platform_list():
    url = 'https://www.p2peye.com/platformData.php?mod=issue&ajax=1&action=getPage&page='
    page = 1
    while True:
        try:
            req = build_request(url+str(page))
            data = req.json()['data']
        except Exception as e:
            print(page, 'fail', e)
            continue
        if data == '':
            break
        f = open('./platform_list.txt', "a", encoding="utf-8")
        for info in data:
            line = []
            for key in ['name', 'black_time', 'city_name', 'online_time', 'black_type_name', 'black_url']:
                line.append(info[key])
            f.write(json.dumps(line)+"\n")
        f.close()
        print(page, 'OK')
        page += 1


def load_platform():
    items = []
    for line in open('platform_list.txt', 'r', encoding='utf-8'):
        item = json.loads(line)
        items.append(item)
        if len(items) < 20:
            continue
        yield items
        items=[]
    yield items


def get_platform_detail(url):
    infolist = ["" for i in range(7)]
    req = build_request(url)
    bs_obj = BeautifulSoup(req.text, 'lxml')
    trlist = bs_obj.find('table', class_='t_table').find_all('tr')
    for i in range(len(trlist)):
        if trlist[i].find_all('td')[0].get_text().strip() == '注册资本':
            infolist[0] = trlist[i].find_all('td')[1].get_text()
        elif trlist[i].find_all('td')[0].get_text().strip() == '法人':
            infolist[1] = trlist[i].find_all('td')[1].get_text()
        elif trlist[i].find_all('td')[0].get_text().strip() == '风险暴露时间':
            infolist[2] = trlist[i].find_all('td')[1].get_text()
        elif trlist[i].find_all('td')[0].get_text().strip() == '注册人数':
            infolist[3] = trlist[i].find_all('td')[1].get_text()
        elif trlist[i].find_all('td')[0].get_text().strip() == '募集资金':
            infolist[4] = trlist[i].find_all('td')[1].get_text()
        elif trlist[i].find_all('td')[0].get_text().strip() == '待收金额':
            infolist[5] = trlist[i].find_all('td')[1].get_text()
        elif trlist[i].find_all('td')[0].get_text().strip() == '现状':
            infolist[6] = trlist[i].find_all('td')[1].get_text()
    return infolist


class Detail(Thread):
    def __init__(self, base_info):
        Thread.__init__(self)
        self.base_info = base_info
        self.daemon = True

    def run(self):
        try:
            self.detail_info = get_platform_detail(self.base_info[-1])
        except:
            self.result = self.base_info
            return
        self.result = self.base_info+self.detail_info


def crawl():
    keys = ["问题发生时间", "平台名称", "所在地区", "上线时间", "出问题原因",
            "url", "注册资本", "法人", "风险暴露时间", "注册人数", "筹集资金", "待收金额", "现状"]
    get_platform_list()
    result = []
    result.append(keys)
    count = 0
    for items in load_platform():
        tasks = []
        for item in items:
            task = Detail(item)
            tasks.append(task)
        for task in tasks:
            task.start()
        for task in tasks:
            task.join()
        for task in tasks:
            result.append(task.result)
            count += 1
        print(count, 'OK')
    write_to_excel(result, '平台信息.xlsx')


crawl()
